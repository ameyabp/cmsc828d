# WINDOWS environment
# set environment variable PGUSER=postgres
createdb assignment1
